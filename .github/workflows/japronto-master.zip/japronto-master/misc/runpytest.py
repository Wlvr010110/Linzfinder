from pytest import main

main()
