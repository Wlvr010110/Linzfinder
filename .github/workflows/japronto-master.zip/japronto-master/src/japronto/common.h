#pragma once


typedef enum {
  KEEP_ALIVE_UNSET,
  KEEP_ALIVE_TRUE,
  KEEP_ALIVE_FALSE
} KEEP_ALIVE;
